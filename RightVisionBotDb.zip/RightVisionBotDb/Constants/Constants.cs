﻿#pragma warning disable IDE0130 // Пространство имен (namespace) не соответствует структуре папок.
namespace RightVisionBotDb
#pragma warning restore IDE0130 // Пространство имен (namespace) не соответствует структуре папок.
{
    public class Constants
    {
        public class GroupId
        {
            public const long
                ParticipantGroupId = -1002074764678,
                CriticGroupId = -1001968408177;
        }

        public class Links
        {
            public const string
                ParticipantGroupLink = "https://t.me/+p-NYz5VLgYBjZTMy",
                CriticGroupLink = "https://t.me/+vUBCHXqsoP9lOTAy";
        }

    }
}
