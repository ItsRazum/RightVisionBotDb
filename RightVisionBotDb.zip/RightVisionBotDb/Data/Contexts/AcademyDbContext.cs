﻿using Microsoft.EntityFrameworkCore;

namespace RightVisionBotDb.Data.Contexts
{
    internal class AcademyDbContext : DbContext
    {

    }
}
