﻿using RightVisionBotDb.Types;
using System.Text;
using Telegram.Bot.Types.ReplyMarkups;

namespace RightVisionBotDb.Helpers
{
    public static class AcademyHelper
    {
        public static(string content, InlineKeyboardMarkup? keyboard) MainMenu(CallbackContext c)
        {
            var sb = new StringBuilder();

            return (string.Empty, null);
        }
    }
}
