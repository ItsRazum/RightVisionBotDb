﻿namespace RightVisionBotDb.Text.Interfaces
{
    public interface ITimeFormat
    {
        string Singular { get; set; }
        string Plural { get; set; }
        string Genitive { get; set; }
    }
}
