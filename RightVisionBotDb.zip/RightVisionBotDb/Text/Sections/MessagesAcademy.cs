﻿namespace RightVisionBotDb.Text.Sections
{
    public class MessagesAcademy
    {
        public string EnrollmentClosed { get; set; }
    }
}
