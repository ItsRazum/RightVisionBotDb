﻿namespace RightVisionBotDb.Text.Sections
{
    public class ProfileParticipations
    {
        public string HowManyParticipations { get; set; }
    }
}
