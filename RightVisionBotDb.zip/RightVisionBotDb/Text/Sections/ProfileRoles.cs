﻿namespace RightVisionBotDb.Text.Sections
{
    public class ProfileRoles
    {
        public string None { get; set; }
        public string Designer { get; set; }
        public string Translator { get; set; }
        public string Moderator { get; set; }
        public string SeniorModerator { get; set; }
        public string TechAdmin { get; set; }
        public string Developer { get; set; }
        public string Curator { get; set; }
        public string Admin { get; set; }
        public string Student { get; set; }
        public string Teacher { get; set; }
    }
}
