﻿namespace RightVisionBotDb.Text.Sections
{
    public class MessagesProfileSending
    {
        public string SubscribeSuccess { get; set; }
        public string UnsubscribeSuccess { get; set; }
    }
}
