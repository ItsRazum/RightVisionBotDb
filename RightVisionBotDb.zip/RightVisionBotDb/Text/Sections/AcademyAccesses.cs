﻿namespace RightVisionBotDb.Text.Sections
{
    public class AcademyAccesses
    {
        public string Allowed { get; set; }
        public string UnderConsideration { get; set; }
        public string Student { get; set; }
        public string Teacher { get; set; }
        public string NoAccess { get; set; }
    }
}
