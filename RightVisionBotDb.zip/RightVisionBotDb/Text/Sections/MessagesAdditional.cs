﻿namespace RightVisionBotDb.Text.Sections
{
    public class MessagesAdditional
    {
        public string HowMuchLeft { get; set; }
        public string Time { get; set; }
        public string Present { get; set; }
    }
}
