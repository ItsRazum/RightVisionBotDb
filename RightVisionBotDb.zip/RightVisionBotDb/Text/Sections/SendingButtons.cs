﻿namespace RightVisionBotDb.Text.Sections
{
    public class SendingButtons
    {
        public string Subscribe { get; set; }
        public string Unsubscribe { get; set; }
    }
}
