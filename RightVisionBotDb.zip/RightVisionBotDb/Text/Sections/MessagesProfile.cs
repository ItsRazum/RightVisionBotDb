﻿namespace RightVisionBotDb.Text.Sections
{
    public class MessagesProfile
    {
        public MessagesProfileSending Sending { get; set; }
    }
}
