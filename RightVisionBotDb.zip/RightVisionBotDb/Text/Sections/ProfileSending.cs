﻿namespace RightVisionBotDb.Text.Sections
{

    public class ProfileSending
    {
        public string Header { get; set; }
        public string Active { get; set; }
        public string Inactive { get; set; }
    }
}
