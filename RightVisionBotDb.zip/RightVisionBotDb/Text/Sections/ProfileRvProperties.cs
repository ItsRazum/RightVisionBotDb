﻿namespace RightVisionBotDb.Text.Sections
{
    public class ProfileRvProperties
    {
        public string Date { get; set; }
        public string ParticipantsCount { get; set; }
    }
}
