﻿namespace RightVisionBotDb.Text.Sections
{
    public class FormsProperties
    {
        public string Participant { get; set; }
        public string Critic { get; set; }
    }
}
