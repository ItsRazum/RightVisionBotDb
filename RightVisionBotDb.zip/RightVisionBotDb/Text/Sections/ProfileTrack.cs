﻿namespace RightVisionBotDb.Text.Sections
{
    public class ProfileTrack
    {
        public string Hidden { get; set; }
    }
}
