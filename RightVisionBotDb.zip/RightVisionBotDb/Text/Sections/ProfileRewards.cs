﻿namespace RightVisionBotDb.Text.Sections
{
    public class ProfileRewards
    {
        public string Header { get; set; }
        public string NoRewards { get; set; }
    }
}
