﻿namespace RightVisionBotDb.Text.Sections
{
    public class TrackCardProperties
    {
        public string AudioFile { get; set; }
        public string ImageFile { get; set; }
        public string TextFile { get; set; }
    }
}
