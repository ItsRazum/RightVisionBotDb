﻿namespace RightVisionBotDb.Text.Sections
{
    public class ProfileHeaders
    {
        public string Global { get; set; }
        public string Private { get; set; }
    }
}
