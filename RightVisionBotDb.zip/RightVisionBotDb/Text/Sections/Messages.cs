﻿namespace RightVisionBotDb.Text.Sections
{
    public class Messages
    {
        public MessagesAdditional Additional { get; set; }
        public MessagesProfile Profile { get; set; }
        public MessagesCommon Common { get; set; }
        public MessagesCritic Critic { get; set; }
        public MessagesParticipant Participant { get; set; }
        public MessagesAcademy Academy { get; set; }
    }
}
