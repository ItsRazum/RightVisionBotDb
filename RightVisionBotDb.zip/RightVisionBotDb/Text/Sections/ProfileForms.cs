﻿namespace RightVisionBotDb.Text.Sections
{
    public class ProfileForms
    {
        public FormsProperties Properties { get; set; }
        public ProfileFormStatus Status { get; set; }
    }
}
