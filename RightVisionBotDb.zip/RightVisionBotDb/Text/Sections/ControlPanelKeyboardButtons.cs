﻿namespace RightVisionBotDb.Text.Sections
{
    public class ControlPanelKeyboardButtons
    {
        public string ExploreUsers { get; set; }
        public string ExploreCritics { get; set; }
        public string ExploreParticipants { get; set; }
    }
}
