﻿namespace RightVisionBotDb.Text.Sections
{
    public class Academy
    {
        public string Greetings { get; set; }
        public AcademyAccesses Accesses { get; set; }
        public AcademyProperties Properties { get; set; }
    }
}
