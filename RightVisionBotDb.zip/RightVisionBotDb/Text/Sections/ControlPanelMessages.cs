﻿namespace RightVisionBotDb.Text.Sections
{
    public class ControlPanelMessages
    {
        public string Welcome { get; set; }
    }
}