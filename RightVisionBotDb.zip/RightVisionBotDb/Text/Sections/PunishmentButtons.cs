﻿namespace RightVisionBotDb.Text.Sections
{
    public class PunishmentButtons
    {
        public string ShowBans { get; set; }
        public string ShowMutes { get; set; }
    }
}
