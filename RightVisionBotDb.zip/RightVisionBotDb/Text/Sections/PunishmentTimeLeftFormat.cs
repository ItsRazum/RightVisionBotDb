﻿namespace RightVisionBotDb.Text.Sections
{
    public class PunishmentTimeLeftFormat
    {
        public DaysFormat Days { get; set; }
        public HoursFormat Hours { get; set; }
        public MinutesFormat Minutes { get; set; }
    }
}
