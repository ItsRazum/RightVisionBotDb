﻿namespace RightVisionBotDb.Text.Sections
{
    public class CriticMenu
    {
        public string Open { get; set; }
        public string PreListening { get; set; }
        public string Voting { get; set; }
    }
}
