﻿namespace RightVisionBotDb.Text.Sections
{

    public class ProfilePermissions
    {
        public string Header { get; set; }
        public string HeaderGlobal { get; set; }
        public string FullList { get; set; }
        public string AddedList { get; set; }
        public string BlockedList { get; set; }
    }
}
