﻿namespace RightVisionBotDb.Text.Sections
{
    public class AcademyProperties
    {
        public string Role { get; set; }
    }
}
