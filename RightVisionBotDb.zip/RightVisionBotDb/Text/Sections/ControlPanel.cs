﻿namespace RightVisionBotDb.Text.Sections
{
    public class ControlPanel
    {
        public ControlPanelKeyboardButtons KeyboardButtons { get; set; }
        public ControlPanelMessages Messages { get; set; }
    }
}
