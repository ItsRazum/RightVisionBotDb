﻿namespace RightVisionBotDb.Settings
{
    public class ContestSettings
    {
        public string DefaultRightVision { get; set; }
    }
}
