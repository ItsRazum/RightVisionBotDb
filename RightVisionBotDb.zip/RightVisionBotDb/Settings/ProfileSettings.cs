﻿namespace RightVisionBotDb.Settings
{
    public class ProfileSettings
    {
        public int PermissionsMinimizedUnitsCount { get; set; }
    }
}
