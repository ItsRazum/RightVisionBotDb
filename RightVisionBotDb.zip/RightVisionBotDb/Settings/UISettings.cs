﻿namespace RightVisionBotDb.Settings
{
    public class UISettings
    {
        public ProfileSettings ProfileSettings { get; set; }
        public ControlPanelSettings ControlPanelSettings { get; set; }
    }
}
