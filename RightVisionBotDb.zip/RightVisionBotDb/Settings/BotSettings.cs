﻿namespace RightVisionBotDb.Settings
{
    public class BotSettings
    {
        public string Token { get; set; }
        public string BuildDate { get; set; }
    }
}
