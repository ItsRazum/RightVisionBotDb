﻿namespace RightVisionBotDb.Settings
{
    public class ControlPanelSettings
    {
        public int UsersPerPageCount { get; set; }
    }
}
