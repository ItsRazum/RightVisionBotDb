﻿namespace RightVisionBotDb.Settings
{
    public class HiddenBotSettings
    {
        public string HiddenToken { get; set; }
    }
}
