﻿namespace RightVisionBotDb.Enums;

public enum Category
{
    None,
    Bronze,
    Silver,
    Gold,
    Brilliant
}
