﻿namespace RightVisionBotDb.Enums;

public enum Status
{
    User,
    Participant,
    ExParticipant,
    Critic,
    CriticAndParticipant,
    CriticAndExParticipant
}
