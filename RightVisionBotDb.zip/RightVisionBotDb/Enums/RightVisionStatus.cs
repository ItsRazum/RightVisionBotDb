﻿namespace RightVisionBotDb.Enums
{
    public enum RightVisionStatus
    {
        Relevant,
        Irrelevant
    }
}
