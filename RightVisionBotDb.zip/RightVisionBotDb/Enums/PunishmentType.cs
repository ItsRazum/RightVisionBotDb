﻿namespace RightVisionBotDb.Enums
{
    public enum PunishmentType
    {
        Ban,
        Mute
    }
}
