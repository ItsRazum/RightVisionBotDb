﻿namespace RightVisionBotDb.Enums
{
    [Flags]
    public enum BotParameters
    {
        EnableAcademy,
    }
}
