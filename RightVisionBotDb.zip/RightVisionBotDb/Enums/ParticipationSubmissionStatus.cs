﻿namespace RightVisionBotDb.Enums
{
    public enum EnrollmentStatus
    {
        Open,
        Closed
    }
}
