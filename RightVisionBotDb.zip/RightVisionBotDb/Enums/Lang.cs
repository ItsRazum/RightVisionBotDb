﻿namespace RightVisionBotDb.Enums
{
    public enum Lang
    {
        Ru,
        Ua,
        Kz,
        Na
    }
}
